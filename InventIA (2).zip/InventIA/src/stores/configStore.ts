import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";

interface ConfigStore {
  sheetsApiUrl: string;
  googleCalendarApiKey: string;
  makeN8nWebhookUrl: string;
  autoRefreshInterval: number;
  setSheetsApiUrl: (url: string) => void;
  setGoogleCalendarApiKey: (key: string) => void;
  setMakeN8nWebhookUrl: (url: string) => void;
  setAutoRefreshInterval: (interval: number) => void;
  resetConfig: () => void;
}

const defaultConfig = {
  sheetsApiUrl: "",
  googleCalendarApiKey: "",
  makeN8nWebhookUrl: "",
  autoRefreshInterval: 30, // seconds
};

export const useConfigStore = create<ConfigStore>()(
  persist(
    (set, get) => ({
      ...defaultConfig,
      setSheetsApiUrl: (url: string) => set({ sheetsApiUrl: url }),
      setGoogleCalendarApiKey: (key: string) => set({ googleCalendarApiKey: key }),
      setMakeN8nWebhookUrl: (url: string) => set({ makeN8nWebhookUrl: url }),
      setAutoRefreshInterval: (interval: number) => set({ autoRefreshInterval: interval }),
      resetConfig: () => set(defaultConfig),
    }),
    {
      name: "bodega-smart-config",
      storage: createJSONStorage(() => localStorage),
    },
  ),
);
