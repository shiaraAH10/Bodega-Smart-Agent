import React from "react";
import { type LucideProps } from "lucide-react";

interface DashboardCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ComponentType<LucideProps>;
  variant?: "default" | "warning" | "success";
  trend?: {
    value: number;
    isPositive: boolean;
  };
}

export function DashboardCard({ 
  title, 
  value, 
  subtitle, 
  icon: Icon, 
  variant = "default",
  trend 
}: DashboardCardProps) {
  const variantStyles = {
    default: "bg-white border-gray-200 text-gray-900",
    warning: "bg-gradient-to-r from-orange-50 to-orange-100 border-orange-200 text-orange-900",
    success: "bg-gradient-to-r from-green-50 to-green-100 border-green-200 text-green-900",
  };

  const iconStyles = {
    default: "bg-blue-100 text-blue-600",
    warning: "bg-orange-100 text-orange-600", 
    success: "bg-green-100 text-green-600",
  };

  return (
    <div className={`p-6 rounded-xl border shadow-lg hover:shadow-xl transition-all duration-300 ${variantStyles[variant]}`}>
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium text-gray-600 mb-1">{title}</p>
          <p className="text-3xl font-bold mb-2">{value}</p>
          {subtitle && (
            <p className="text-sm text-gray-500">{subtitle}</p>
          )}
          {trend && (
            <div className="flex items-center mt-2">
              <span className={`text-xs font-medium ${trend.isPositive ? 'text-green-600' : 'text-red-600'}`}>
                {trend.isPositive ? '↗' : '↘'} {Math.abs(trend.value)}%
              </span>
              <span className="text-xs text-gray-500 ml-1">vs mes anterior</span>
            </div>
          )}
        </div>
        <div className={`p-3 rounded-lg ${iconStyles[variant]}`}>
          <Icon size={24} />
        </div>
      </div>
    </div>
  );
}
