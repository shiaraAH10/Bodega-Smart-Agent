import React from "react";

export function LoadingAnimation() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-gray-100 flex items-center justify-center">
      <div className="text-center">
        {/* Animated logo/icon */}
        <div className="mb-8 relative">
          <div className="w-20 h-20 mx-auto bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center shadow-2xl">
            <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center">
              <div className="w-6 h-6 bg-gradient-to-r from-orange-500 to-orange-600 rounded animate-pulse"></div>
            </div>
          </div>
          {/* Rotating ring */}
          <div className="absolute inset-0 w-20 h-20 mx-auto border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin"></div>
        </div>

        {/* Loading text */}
        <div className="space-y-4">
          <h2 className="text-2xl font-bold text-gray-800">
            Analizando tus productos con IA...
          </h2>
          <div className="flex justify-center space-x-1">
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce"></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: "0.1s" }}></div>
            <div className="w-2 h-2 bg-blue-600 rounded-full animate-bounce" style={{ animationDelay: "0.2s" }}></div>
          </div>
          <p className="text-gray-600 max-w-md mx-auto">
            Estamos procesando los datos de tu inventario para generar insights inteligentes sobre la rotación de productos.
          </p>
        </div>

        {/* Progress bar */}
        <div className="mt-8 w-64 mx-auto bg-gray-200 rounded-full h-2">
          <div className="bg-gradient-to-r from-blue-600 to-orange-500 h-2 rounded-full animate-pulse" style={{ width: "75%" }}></div>
        </div>
      </div>
    </div>
  );
}
