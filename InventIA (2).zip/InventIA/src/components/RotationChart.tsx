import React from "react";

interface RotationChartProps {
  data: Array<{
    producto: string;
    rotacion: number;
    alta_rotacion: boolean;
  }>;
}

export function RotationChart({ data }: RotationChartProps) {
  const maxRotation = Math.max(...data.map(item => item.rotacion), 100);
  const topProducts = data.slice(0, 8); // Show top 8 products

  return (
    <div className="bg-white p-6 rounded-xl shadow-lg">
      <h3 className="text-lg font-semibold text-gray-800 mb-6">Rotación por Producto</h3>
      <div className="space-y-4">
        {topProducts.map((item, index) => (
          <div key={item.producto} className="flex items-center space-x-4">
            <div className="w-32 text-sm font-medium text-gray-700 truncate">
              {item.producto}
            </div>
            <div className="flex-1 bg-gray-200 rounded-full h-6 relative overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-1000 ease-out ${
                  item.alta_rotacion
                    ? "bg-gradient-to-r from-orange-500 to-red-500"
                    : "bg-gradient-to-r from-blue-500 to-blue-600"
                }`}
                style={{
                  width: `${(item.rotacion / maxRotation) * 100}%`,
                  animationDelay: `${index * 100}ms`
                }}
              />
              <div className="absolute inset-0 flex items-center justify-end pr-2">
                <span className="text-xs font-bold text-white drop-shadow">
                  {item.rotacion.toFixed(1)}%
                </span>
              </div>
            </div>
            {item.alta_rotacion && (
              <div className="text-orange-600 text-sm font-medium">⚠️ Alta</div>
            )}
          </div>
        ))}
      </div>
      {data.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No hay datos de rotación disponibles
        </div>
      )}
    </div>
  );
}
