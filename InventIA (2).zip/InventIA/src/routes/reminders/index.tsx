import React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Bell, Calendar, ExternalLink, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { useTRPC } from "~/trpc/react";
import toast from "react-hot-toast";

export const Route = createFileRoute("/reminders/")({
  component: RemindersPage,
});

function RemindersPage() {
  const trpc = useTRPC();
  
  const remindersQuery = useQuery({
    ...trpc.getReminders.queryOptions(),
    refetchOnWindowFocus: true,
  });

  const sendReminderMutation = useMutation({
    ...trpc.sendReminder.mutationOptions(),
    onSuccess: (data) => {
      toast.success(data.message);
      remindersQuery.refetch();
    },
    onError: (error) => {
      toast.error("Error al programar recordatorio");
    },
  });

  const handleCreateReminder = (producto: string) => {
    sendReminderMutation.mutate({ producto });
  };

  const handleViewInCalendar = (recordatorio: any) => {
    // In a real implementation, this would open Google Calendar
    toast.success(`Abriendo calendario para: ${recordatorio.producto}`);
  };

  if (remindersQuery.isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-8"></div>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="bg-white rounded-xl shadow-lg p-6">
                <div className="h-6 bg-gray-200 rounded mb-2"></div>
                <div className="h-4 bg-gray-200 rounded w-2/3"></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (remindersQuery.error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-800 mb-2">Error al cargar recordatorios</h3>
          <p className="text-red-600">No se pudieron obtener los recordatorios programados.</p>
        </div>
      </div>
    );
  }

  const recordatorios = remindersQuery.data?.recordatorios || [];
  const pendientes = recordatorios.filter(r => r.estado === "pendiente");
  const completados = recordatorios.filter(r => r.estado === "completado");

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Recordatorios de Reposición</h1>
        <p className="text-gray-600">
          Gestiona los recordatorios automáticos para productos de alta rotación
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-lg mr-4">
              <Clock size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Pendientes</p>
              <p className="text-2xl font-bold text-gray-900">{pendientes.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 text-green-600 rounded-lg mr-4">
              <CheckCircle size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Completados</p>
              <p className="text-2xl font-bold text-gray-900">{completados.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-lg mr-4">
              <Bell size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total</p>
              <p className="text-2xl font-bold text-gray-900">{recordatorios.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Pending Reminders */}
      {pendientes.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <Clock className="w-5 h-5 mr-2 text-orange-600" />
            Recordatorios Pendientes
          </h2>
          <div className="space-y-4">
            {pendientes.map((recordatorio) => (
              <div key={recordatorio.id} className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-orange-500">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {recordatorio.titulo}
                    </h3>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <Calendar className="w-4 h-4 mr-1" />
                      <span>Programado para: {new Date(recordatorio.fechaProgramada).toLocaleDateString('es-ES', {
                        weekday: 'long',
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric'
                      })}</span>
                    </div>
                    <p className="text-sm text-gray-500">
                      Producto: <span className="font-medium">{recordatorio.producto}</span>
                    </p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={() => handleViewInCalendar(recordatorio)}
                      className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <ExternalLink className="w-4 h-4 mr-2" />
                      Ver en Calendar
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Completed Reminders */}
      {completados.length > 0 && (
        <div className="mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
            <CheckCircle className="w-5 h-5 mr-2 text-green-600" />
            Recordatorios Completados
          </h2>
          <div className="space-y-4">
            {completados.map((recordatorio) => (
              <div key={recordatorio.id} className="bg-white rounded-xl shadow-lg p-6 border-l-4 border-green-500 opacity-75">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">
                      {recordatorio.titulo}
                    </h3>
                    <div className="flex items-center text-sm text-gray-600 mb-2">
                      <Calendar className="w-4 h-4 mr-1" />
                      <span>Completado: {new Date(recordatorio.fechaProgramada).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm text-gray-500">
                      Producto: <span className="font-medium">{recordatorio.producto}</span>
                    </p>
                  </div>
                  <div className="flex items-center text-green-600">
                    <CheckCircle className="w-6 h-6" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Acciones Rápidas</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <button
            onClick={() => handleCreateReminder("Producto de prueba")}
            disabled={sendReminderMutation.isPending}
            className="p-4 bg-orange-50 hover:bg-orange-100 rounded-lg border border-orange-200 transition-colors text-left disabled:opacity-50"
          >
            <h4 className="font-medium text-orange-900 mb-1">
              {sendReminderMutation.isPending ? "Creando..." : "Crear Recordatorio de Prueba"}
            </h4>
            <p className="text-sm text-orange-700">Programar recordatorio para mañana</p>
          </button>
          <button className="p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors text-left">
            <h4 className="font-medium text-blue-900 mb-1">Sincronizar con Calendar</h4>
            <p className="text-sm text-blue-700">Actualizar recordatorios desde Google Calendar</p>
          </button>
        </div>
      </div>

      {recordatorios.length === 0 && (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <Bell className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No hay recordatorios programados</h3>
          <p className="text-gray-500 mb-6">Los recordatorios se crearán automáticamente para productos de alta rotación.</p>
          <button
            onClick={() => handleCreateReminder("Producto de ejemplo")}
            disabled={sendReminderMutation.isPending}
            className="bg-orange-600 text-white px-6 py-3 rounded-lg hover:bg-orange-700 transition-colors disabled:opacity-50"
          >
            {sendReminderMutation.isPending ? "Creando..." : "Crear Recordatorio de Prueba"}
          </button>
        </div>
      )}
    </div>
  );
}
