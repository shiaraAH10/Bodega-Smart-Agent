import React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useForm } from "react-hook-form";
import { Settings, Save, RefreshCw, ExternalLink, Key, Link, Webhook } from "lucide-react";
import { useConfigStore } from "~/stores/configStore";
import toast from "react-hot-toast";

export const Route = createFileRoute("/settings/")({
  component: SettingsPage,
});

interface ConfigForm {
  sheetsApiUrl: string;
  googleCalendarApiKey: string;
  makeN8nWebhookUrl: string;
  autoRefreshInterval: number;
}

function SettingsPage() {
  const {
    sheetsApiUrl,
    googleCalendarApiKey,
    makeN8nWebhookUrl,
    autoRefreshInterval,
    setSheetsApiUrl,
    setGoogleCalendarApiKey,
    setMakeN8nWebhookUrl,
    setAutoRefreshInterval,
    resetConfig,
  } = useConfigStore();

  const { register, handleSubmit, reset, formState: { errors, isDirty } } = useForm<ConfigForm>({
    defaultValues: {
      sheetsApiUrl,
      googleCalendarApiKey,
      makeN8nWebhookUrl,
      autoRefreshInterval,
    },
  });

  const onSubmit = (data: ConfigForm) => {
    setSheetsApiUrl(data.sheetsApiUrl);
    setGoogleCalendarApiKey(data.googleCalendarApiKey);
    setMakeN8nWebhookUrl(data.makeN8nWebhookUrl);
    setAutoRefreshInterval(data.autoRefreshInterval);
    
    toast.success("Configuración guardada correctamente");
    reset(data);
  };

  const handleReset = () => {
    resetConfig();
    reset({
      sheetsApiUrl: "",
      googleCalendarApiKey: "",
      makeN8nWebhookUrl: "",
      autoRefreshInterval: 30,
    });
    toast.success("Configuración restablecida");
  };

  const testConnection = (type: string, url: string) => {
    if (!url) {
      toast.error("Por favor ingresa una URL válida");
      return;
    }
    
    // Simulate connection test
    toast.loading(`Probando conexión con ${type}...`, { duration: 2000 });
    setTimeout(() => {
      toast.success(`Conexión con ${type} exitosa`);
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Configuración</h1>
        <p className="text-gray-600">
          Configura las integraciones con sistemas externos y personaliza el comportamiento de la aplicación
        </p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        {/* Google Sheets Integration */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <div className="p-2 bg-green-100 text-green-600 rounded-lg mr-3">
              <Link size={20} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Google Sheets</h2>
              <p className="text-sm text-gray-600">Conecta con tu hoja de cálculo de inventario</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="sheetsApiUrl" className="block text-sm font-medium text-gray-700 mb-2">
                URL de API de Google Sheets
              </label>
              <div className="flex space-x-2">
                <input
                  {...register("sheetsApiUrl", {
                    pattern: {
                      value: /^https?:\/\/.+/,
                      message: "Debe ser una URL válida"
                    }
                  })}
                  type="url"
                  id="sheetsApiUrl"
                  placeholder="https://sheets.googleapis.com/v4/spreadsheets/..."
                  className="flex-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => testConnection("Google Sheets", sheetsApiUrl)}
                  className="px-4 py-2 bg-green-600 text-white rounded-md hover:bg-green-700 transition-colors"
                >
                  Probar
                </button>
              </div>
              {errors.sheetsApiUrl && (
                <p className="mt-1 text-sm text-red-600">{errors.sheetsApiUrl.message}</p>
              )}
            </div>
            
            <div className="bg-green-50 border border-green-200 rounded-lg p-4">
              <h4 className="font-medium text-green-800 mb-2">¿Cómo obtener la URL?</h4>
              <ol className="text-sm text-green-700 space-y-1 list-decimal list-inside">
                <li>Abre tu Google Sheet con los datos de inventario</li>
                <li>Ve a "Extensiones" → "Apps Script"</li>
                <li>Publica como aplicación web y copia la URL</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Google Calendar Integration */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg mr-3">
              <Key size={20} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Google Calendar</h2>
              <p className="text-sm text-gray-600">API para programar recordatorios automáticos</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="googleCalendarApiKey" className="block text-sm font-medium text-gray-700 mb-2">
                Clave de API de Google Calendar
              </label>
              <div className="flex space-x-2">
                <input
                  {...register("googleCalendarApiKey")}
                  type="password"
                  id="googleCalendarApiKey"
                  placeholder="AIzaSyD..."
                  className="flex-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => testConnection("Google Calendar", googleCalendarApiKey)}
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
                >
                  Probar
                </button>
              </div>
            </div>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-medium text-blue-800 mb-2">¿Cómo obtener la clave API?</h4>
              <ol className="text-sm text-blue-700 space-y-1 list-decimal list-inside">
                <li>Ve a Google Cloud Console</li>
                <li>Habilita la API de Google Calendar</li>
                <li>Crea credenciales y copia la clave API</li>
              </ol>
            </div>
          </div>
        </div>

        {/* Make/n8n Integration */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <div className="p-2 bg-purple-100 text-purple-600 rounded-lg mr-3">
              <Webhook size={20} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Make / n8n</h2>
              <p className="text-sm text-gray-600">Webhook para automatizaciones avanzadas</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="makeN8nWebhookUrl" className="block text-sm font-medium text-gray-700 mb-2">
                URL de Webhook
              </label>
              <div className="flex space-x-2">
                <input
                  {...register("makeN8nWebhookUrl", {
                    pattern: {
                      value: /^https?:\/\/.+/,
                      message: "Debe ser una URL válida"
                    }
                  })}
                  type="url"
                  id="makeN8nWebhookUrl"
                  placeholder="https://hook.integromat.com/..."
                  className="flex-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                />
                <button
                  type="button"
                  onClick={() => testConnection("Make/n8n", makeN8nWebhookUrl)}
                  className="px-4 py-2 bg-purple-600 text-white rounded-md hover:bg-purple-700 transition-colors"
                >
                  Probar
                </button>
              </div>
              {errors.makeN8nWebhookUrl && (
                <p className="mt-1 text-sm text-red-600">{errors.makeN8nWebhookUrl.message}</p>
              )}
            </div>
          </div>
        </div>

        {/* App Settings */}
        <div className="bg-white rounded-xl shadow-lg p-6">
          <div className="flex items-center mb-6">
            <div className="p-2 bg-gray-100 text-gray-600 rounded-lg mr-3">
              <Settings size={20} />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">Configuración de la Aplicación</h2>
              <p className="text-sm text-gray-600">Personaliza el comportamiento de la app</p>
            </div>
          </div>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="autoRefreshInterval" className="block text-sm font-medium text-gray-700 mb-2">
                Intervalo de actualización automática (segundos)
              </label>
              <input
                {...register("autoRefreshInterval", {
                  min: { value: 10, message: "Mínimo 10 segundos" },
                  max: { value: 300, message: "Máximo 300 segundos" },
                  valueAsNumber: true,
                })}
                type="number"
                id="autoRefreshInterval"
                min="10"
                max="300"
                className="block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              />
              {errors.autoRefreshInterval && (
                <p className="mt-1 text-sm text-red-600">{errors.autoRefreshInterval.message}</p>
              )}
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex justify-between items-center">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Restablecer
          </button>
          
          <button
            type="submit"
            disabled={!isDirty}
            className="flex items-center px-6 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
          >
            <Save className="w-4 h-4 mr-2" />
            Guardar Configuración
          </button>
        </div>
      </form>
    </div>
  );
}
