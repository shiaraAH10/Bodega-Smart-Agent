import React, { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Package, TrendingUp, AlertTriangle, BarChart3 } from "lucide-react";
import { useTRPC } from "~/trpc/react";
import { DashboardCard } from "~/components/DashboardCard";
import { RotationChart } from "~/components/RotationChart";
import { LoadingAnimation } from "~/components/LoadingAnimation";
import { useConfigStore } from "~/stores/configStore";
import toast from "react-hot-toast";

export const Route = createFileRoute("/")({
  component: Dashboard,
});

function Dashboard() {
  const trpc = useTRPC();
  const [showLoading, setShowLoading] = useState(true);
  const autoRefreshInterval = useConfigStore((state) => state.autoRefreshInterval);
  
  const rotationQuery = useQuery({
    ...trpc.getRotationData.queryOptions(),
    refetchInterval: autoRefreshInterval * 1000, // Convert to milliseconds
    refetchOnWindowFocus: true,
  });

  // Show loading animation on initial load
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowLoading(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // Show alerts for high rotation products
  useEffect(() => {
    if (rotationQuery.data?.productosAltaRotacion?.length) {
      rotationQuery.data.productosAltaRotacion.forEach((producto) => {
        toast.error(`⚠️ ${producto.producto} tiene alta rotación (${producto.rotacion.toFixed(1)}%)`, {
          id: `alta-rotacion-${producto.id}`, // Prevent duplicate toasts
        });
      });
    }
  }, [rotationQuery.data?.productosAltaRotacion]);

  if (showLoading) {
    return <LoadingAnimation />;
  }

  if (rotationQuery.isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4"></div>
          <p className="text-gray-600">Actualizando datos...</p>
        </div>
      </div>
    );
  }

  if (rotationQuery.error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-800 mb-2">Error al cargar datos</h3>
          <p className="text-red-600 mb-4">No se pudieron obtener los datos de rotación.</p>
          <button
            onClick={() => rotationQuery.refetch()}
            className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
          >
            Reintentar
          </button>
        </div>
      </div>
    );
  }

  const data = rotationQuery.data;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Panel de Rotación de Productos</h1>
        <p className="text-gray-600">
          Monitoreo inteligente de inventario • Última actualización: {new Date().toLocaleTimeString()}
        </p>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <DashboardCard
          title="Total de Productos"
          value={data?.resumen.totalProductos || 0}
          subtitle="productos analizados"
          icon={Package}
          trend={{ value: 12, isPositive: true }}
        />
        <DashboardCard
          title="Rotación Promedio"
          value={`${data?.resumen.promedioRotacion.toFixed(1) || 0}%`}
          subtitle="promedio general"
          icon={TrendingUp}
          trend={{ value: 8, isPositive: true }}
        />
        <DashboardCard
          title="Alta Rotación"
          value={data?.resumen.productosAltaRotacion || 0}
          subtitle="productos > 60%"
          icon={AlertTriangle}
          variant={data?.resumen.productosAltaRotacion ? "warning" : "default"}
          trend={{ value: 15, isPositive: false }}
        />
      </div>

      {/* Chart */}
      <div className="mb-8">
        <RotationChart data={data?.ranking || []} />
      </div>

      {/* Quick Actions */}
      <div className="bg-white rounded-xl shadow-lg p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
          <BarChart3 className="w-5 h-5 mr-2" />
          Acciones Rápidas
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          <button className="p-4 bg-blue-50 hover:bg-blue-100 rounded-lg border border-blue-200 transition-colors text-left">
            <h4 className="font-medium text-blue-900 mb-1">Ver Ranking Completo</h4>
            <p className="text-sm text-blue-700">Analizar todos los productos</p>
          </button>
          <button className="p-4 bg-orange-50 hover:bg-orange-100 rounded-lg border border-orange-200 transition-colors text-left">
            <h4 className="font-medium text-orange-900 mb-1">Programar Recordatorios</h4>
            <p className="text-sm text-orange-700">Para productos de alta rotación</p>
          </button>
          <button className="p-4 bg-gray-50 hover:bg-gray-100 rounded-lg border border-gray-200 transition-colors text-left">
            <h4 className="font-medium text-gray-900 mb-1">Configurar APIs</h4>
            <p className="text-sm text-gray-700">Conectar con sistemas externos</p>
          </button>
        </div>
      </div>
    </div>
  );
}
