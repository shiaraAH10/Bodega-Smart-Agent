import React from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, TrendingUp, Package, Calendar } from "lucide-react";
import { useTRPC } from "~/trpc/react";

export const Route = createFileRoute("/ranking/")({
  component: RankingPage,
});

function RankingPage() {
  const trpc = useTRPC();
  
  const rotationQuery = useQuery({
    ...trpc.getRotationData.queryOptions(),
    refetchOnWindowFocus: true,
  });

  if (rotationQuery.isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/4 mb-4"></div>
          <div className="h-4 bg-gray-200 rounded w-1/2 mb-8"></div>
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="space-y-4">
              {[...Array(5)].map((_, i) => (
                <div key={i} className="h-16 bg-gray-100 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (rotationQuery.error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-red-800 mb-2">Error al cargar ranking</h3>
          <p className="text-red-600">No se pudieron obtener los datos de rotación.</p>
        </div>
      </div>
    );
  }

  const data = rotationQuery.data;
  const ranking = data?.ranking || [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Ranking de Productos</h1>
        <p className="text-gray-600">
          Productos ordenados por porcentaje de rotación • {ranking.length} productos analizados
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-lg mr-4">
              <Package size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Total Productos</p>
              <p className="text-2xl font-bold text-gray-900">{ranking.length}</p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center">
            <div className="p-3 bg-green-100 text-green-600 rounded-lg mr-4">
              <TrendingUp size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Mayor Rotación</p>
              <p className="text-2xl font-bold text-gray-900">
                {ranking[0]?.rotacion.toFixed(1) || 0}%
              </p>
            </div>
          </div>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-lg">
          <div className="flex items-center">
            <div className="p-3 bg-orange-100 text-orange-600 rounded-lg mr-4">
              <AlertTriangle size={24} />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Alta Rotación</p>
              <p className="text-2xl font-bold text-gray-900">
                {ranking.filter(p => p.alta_rotacion).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Ranking Table */}
      <div className="bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h3 className="text-lg font-semibold text-gray-800">Ranking Detallado</h3>
        </div>
        
        {/* Mobile View */}
        <div className="md:hidden">
          {ranking.map((producto, index) => (
            <div key={producto.id} className="p-4 border-b border-gray-100 last:border-b-0">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center">
                  <span className="text-lg font-bold text-gray-500 mr-2">#{index + 1}</span>
                  <h4 className="font-medium text-gray-900">{producto.producto}</h4>
                  {producto.alta_rotacion && (
                    <AlertTriangle className="w-4 h-4 text-orange-500 ml-2" />
                  )}
                </div>
                <span className={`text-lg font-bold ${
                  producto.alta_rotacion ? 'text-orange-600' : 'text-blue-600'
                }`}>
                  {producto.rotacion.toFixed(1)}%
                </span>
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <p>Stock: {producto.stock_actual} unidades</p>
                <p>Vendidas: {producto.unidades_vendidas} unidades</p>
                <p>Última reposición: {new Date(producto.fecha_ultima_reposicion).toLocaleDateString()}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Desktop View */}
        <div className="hidden md:block overflow-x-auto">
          <table className="min-w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Posición
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Producto
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Stock Actual
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Unidades Vendidas
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  % Rotación
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Última Reposición
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Estado
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {ranking.map((producto, index) => (
                <tr key={producto.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className="text-lg font-bold text-gray-500">#{index + 1}</span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="font-medium text-gray-900">{producto.producto}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {producto.stock_actual}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {producto.unidades_vendidas}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`text-lg font-bold ${
                      producto.alta_rotacion ? 'text-orange-600' : 'text-blue-600'
                    }`}>
                      {producto.rotacion.toFixed(1)}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(producto.fecha_ultima_reposicion).toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    {producto.alta_rotacion ? (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        Alta Rotación
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        Normal
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {ranking.length === 0 && (
        <div className="bg-white rounded-xl shadow-lg p-12 text-center">
          <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No hay productos para mostrar</h3>
          <p className="text-gray-500">Asegúrate de que hay datos de inventario y ventas disponibles.</p>
        </div>
      )}
    </div>
  );
}
