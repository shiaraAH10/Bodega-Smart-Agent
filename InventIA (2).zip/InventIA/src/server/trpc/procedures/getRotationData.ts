import { z } from "zod";
import { db } from "~/server/db";
import { baseProcedure } from "~/server/trpc/main";

export const getRotationData = baseProcedure.query(async () => {
  // Fetch all inventory and sales data
  const inventario = await db.inventario.findMany();
  const ventas = await db.ventas.findMany();

  // Group sales by product and sum quantities
  const ventasPorProducto = ventas.reduce((acc, venta) => {
    if (!acc[venta.producto]) {
      acc[venta.producto] = 0;
    }
    acc[venta.producto] += venta.unidades_vendidas;
    return acc;
  }, {} as Record<string, number>);

  // Calculate rotation for each product
  const productosConRotacion = inventario.map((item) => {
    const unidadesVendidas = ventasPorProducto[item.producto] || 0;
    const rotacion = item.stock_actual > 0 
      ? (unidadesVendidas / item.stock_actual) * 100 
      : 0;

    return {
      id: item.id,
      producto: item.producto,
      stock_actual: item.stock_actual,
      unidades_vendidas: unidadesVendidas,
      rotacion: Math.round(rotacion * 100) / 100, // Round to 2 decimals
      fecha_ultima_reposicion: item.fecha_ultima_reposicion,
      alta_rotacion: rotacion > 60,
    };
  });

  // Sort by rotation descending
  const ranking = productosConRotacion.sort((a, b) => b.rotacion - a.rotacion);

  // Calculate summary metrics
  const totalProductos = productosConRotacion.length;
  const promedioRotacion = totalProductos > 0 
    ? productosConRotacion.reduce((sum, p) => sum + p.rotacion, 0) / totalProductos
    : 0;
  const productosAltaRotacion = productosConRotacion.filter(p => p.alta_rotacion).length;

  return {
    resumen: {
      totalProductos,
      promedioRotacion: Math.round(promedioRotacion * 100) / 100,
      productosAltaRotacion,
    },
    ranking,
    productosAltaRotacion: productosConRotacion.filter(p => p.alta_rotacion),
  };
});
