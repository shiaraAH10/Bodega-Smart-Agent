import { z } from "zod";
import { TRPCError } from "@trpc/server";
import { baseProcedure } from "~/server/trpc/main";
import { env } from "~/server/env";

export const sendReminder = baseProcedure
  .input(z.object({ 
    producto: z.string(),
    fechaProgramada: z.string().optional(),
  }))
  .mutation(async ({ input }) => {
    try {
      // For demo purposes, we'll simulate the API call
      // In a real implementation, this would make actual HTTP requests
      
      const reminderData = {
        title: `Reponer producto: ${input.producto}`,
        description: `Recordatorio automático para reponer ${input.producto} debido a alta rotación`,
        date: input.fechaProgramada || new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(), // Tomorrow by default
      };

      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 1000));

      // In a real implementation, you would do:
      // if (env.GOOGLE_CALENDAR_API_KEY) {
      //   // Make Google Calendar API call
      // } else if (env.MAKE_N8N_WEBHOOK_URL) {
      //   // Make webhook call to Make/n8n
      // }

      return {
        success: true,
        message: `Recordatorio programado para ${input.producto}`,
        reminder: reminderData,
      };
    } catch (error) {
      throw new TRPCError({
        code: "INTERNAL_SERVER_ERROR",
        message: "Error al programar recordatorio",
      });
    }
  });
