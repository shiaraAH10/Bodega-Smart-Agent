import { baseProcedure } from "~/server/trpc/main";

export const getReminders = baseProcedure.query(async () => {
  // For demo purposes, return simulated reminder data
  // In a real implementation, this would fetch from Google Calendar API
  
  const simulatedReminders = [
    {
      id: "1",
      producto: "Aceite de Oliva Premium",
      fechaProgramada: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      titulo: "Reponer producto: Aceite de Oliva Premium",
      estado: "pendiente",
    },
    {
      id: "2", 
      producto: "Arroz Integral",
      fechaProgramada: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
      titulo: "Reponer producto: Arroz Integral",
      estado: "pendiente",
    },
    {
      id: "3",
      producto: "Leche Descremada",
      fechaProgramada: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(),
      titulo: "Reponer producto: Leche Descremada", 
      estado: "completado",
    },
  ];

  return {
    recordatorios: simulatedReminders,
  };
});
