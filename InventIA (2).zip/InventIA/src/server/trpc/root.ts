import {
  createCallerFactory,
  createTRPCRouter,
  baseProcedure,
} from "~/server/trpc/main";
import { getRotationData } from "./procedures/getRotationData";
import { sendReminder } from "./procedures/sendReminder";
import { getReminders } from "./procedures/getReminders";

export const appRouter = createTRPCRouter({
  getRotationData,
  sendReminder,
  getReminders,
});

export type AppRouter = typeof appRouter;

export const createCaller = createCallerFactory(appRouter);
