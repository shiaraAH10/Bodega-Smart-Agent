import { db } from "~/server/db";

async function setup() {
  console.log("🌱 Seeding database with sample data...");

  // Clear existing data
  await db.ventas.deleteMany();
  await db.inventario.deleteMany();

  // Sample inventory data
  const inventarioData = [
    {
      producto: "Aceite de Oliva Premium",
      stock_actual: 25,
      fecha_ultima_reposicion: new Date("2024-01-15"),
    },
    {
      producto: "Arroz Integral 1kg",
      stock_actual: 40,
      fecha_ultima_reposicion: new Date("2024-01-10"),
    },
    {
      producto: "Leche Descremada 1L",
      stock_actual: 15,
      fecha_ultima_reposicion: new Date("2024-01-20"),
    },
    {
      producto: "Pan Integral",
      stock_actual: 30,
      fecha_ultima_reposicion: new Date("2024-01-18"),
    },
    {
      producto: "Yogurt Natural",
      stock_actual: 20,
      fecha_ultima_reposicion: new Date("2024-01-12"),
    },
    {
      producto: "Pasta Integral 500g",
      stock_actual: 35,
      fecha_ultima_reposicion: new Date("2024-01-08"),
    },
    {
      producto: "Tomate Cherry 250g",
      stock_actual: 12,
      fecha_ultima_reposicion: new Date("2024-01-22"),
    },
    {
      producto: "Quinoa 500g",
      stock_actual: 18,
      fecha_ultima_reposicion: new Date("2024-01-14"),
    },
    {
      producto: "Almendras 200g",
      stock_actual: 22,
      fecha_ultima_reposicion: new Date("2024-01-16"),
    },
    {
      producto: "Miel Orgánica 350g",
      stock_actual: 28,
      fecha_ultima_reposicion: new Date("2024-01-11"),
    },
  ];

  // Create inventory records
  for (const item of inventarioData) {
    await db.inventario.create({
      data: item,
    });
  }

  console.log(`✅ Created ${inventarioData.length} inventory items`);

  // Sample sales data - creating multiple sales records per product with varying quantities
  const ventasData = [
    // High rotation products (>60%)
    { producto: "Aceite de Oliva Premium", unidades_vendidas: 20, fecha: new Date("2024-01-23") },
    { producto: "Aceite de Oliva Premium", unidades_vendidas: 15, fecha: new Date("2024-01-24") },
    { producto: "Leche Descremada 1L", unidades_vendidas: 18, fecha: new Date("2024-01-23") },
    { producto: "Leche Descremada 1L", unidades_vendidas: 12, fecha: new Date("2024-01-24") },
    { producto: "Tomate Cherry 250g", unidades_vendidas: 8, fecha: new Date("2024-01-23") },
    { producto: "Tomate Cherry 250g", unidades_vendidas: 10, fecha: new Date("2024-01-24") },
    
    // Medium rotation products
    { producto: "Pan Integral", unidades_vendidas: 8, fecha: new Date("2024-01-23") },
    { producto: "Pan Integral", unidades_vendidas: 6, fecha: new Date("2024-01-24") },
    { producto: "Yogurt Natural", unidades_vendidas: 5, fecha: new Date("2024-01-23") },
    { producto: "Yogurt Natural", unidades_vendidas: 4, fecha: new Date("2024-01-24") },
    { producto: "Quinoa 500g", unidades_vendidas: 6, fecha: new Date("2024-01-23") },
    { producto: "Quinoa 500g", unidades_vendidas: 3, fecha: new Date("2024-01-24") },
    
    // Lower rotation products
    { producto: "Arroz Integral 1kg", unidades_vendidas: 3, fecha: new Date("2024-01-23") },
    { producto: "Arroz Integral 1kg", unidades_vendidas: 4, fecha: new Date("2024-01-24") },
    { producto: "Pasta Integral 500g", unidades_vendidas: 5, fecha: new Date("2024-01-23") },
    { producto: "Pasta Integral 500g", unidades_vendidas: 3, fecha: new Date("2024-01-24") },
    { producto: "Almendras 200g", unidades_vendidas: 2, fecha: new Date("2024-01-23") },
    { producto: "Almendras 200g", unidades_vendidas: 3, fecha: new Date("2024-01-24") },
    { producto: "Miel Orgánica 350g", unidades_vendidas: 4, fecha: new Date("2024-01-23") },
    { producto: "Miel Orgánica 350g", unidades_vendidas: 2, fecha: new Date("2024-01-24") },
  ];

  // Create sales records
  for (const venta of ventasData) {
    await db.ventas.create({
      data: venta,
    });
  }

  console.log(`✅ Created ${ventasData.length} sales records`);
  console.log("🎉 Database seeding completed successfully!");

  // Log some statistics
  const totalInventory = await db.inventario.count();
  const totalSales = await db.ventas.count();
  
  console.log(`📊 Final counts: ${totalInventory} products, ${totalSales} sales records`);
}

setup()
  .then(() => {
    console.log("setup.ts complete");
    process.exit(0);
  })
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
