import { z } from "zod";

const envSchema = z.object({
  NODE_ENV: z.enum(["development", "production"]),
  BASE_URL: z.string().optional(),
  BASE_URL_OTHER_PORT: z.string().optional(),
  ADMIN_PASSWORD: z.string(),
  SHEETS_API_URL: z.string().optional(),
  GOOGLE_CALENDAR_API_KEY: z.string().optional(),
  MAKE_N8N_WEBHOOK_URL: z.string().optional(),
});

export const env = envSchema.parse(process.env);
